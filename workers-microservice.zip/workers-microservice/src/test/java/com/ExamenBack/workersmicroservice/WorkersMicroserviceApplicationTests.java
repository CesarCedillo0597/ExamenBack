package com.ExamenBack.workersmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkersMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
