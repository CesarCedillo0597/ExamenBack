package com.ExamenBack.workersmicroservice.service;

import com.ExamenBack.workersmicroservice.model.Employee;
import com.ExamenBack.workersmicroservice.model.EmployeeWorkedHours;
import com.ExamenBack.workersmicroservice.repository.EmployeeRepository;
import com.ExamenBack.workersmicroservice.repository.EmployeeWorkedHoursRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class EmployeeWorkedHoursService {

    private final EmployeeWorkedHoursRepository employeeWorkedHoursRepository;
    private final EmployeeRepository employeeRepository;

    @Transactional
    public Long addEmployeeWorkedHours(EmployeeWorkedHours employeeWorkedHours) {
        // Validar que el empleado exista

        Employee employee = employeeRepository.findById(employeeWorkedHours.getEmployee().getId())
                .orElseThrow(() -> {
                    System.out.println("El empleado especificado no existe.");
                    return new IllegalArgumentException("El empleado especificado no existe.");
                });




        // Validar que el total de horas trabajadas no sea mayor a 20 horas
        if (employeeWorkedHours.getWorkedHours() > 20) {
            System.out.println("El total de horas trabajadas no puede ser mayor a 20 horas.");
            throw new IllegalArgumentException("El total de horas trabajadas no puede ser mayor a 20 horas.");
        }

        // Validar que la fecha de trabajo sea menor o igual a la actual
        LocalDate currentDate = LocalDate.now();
        if (employeeWorkedHours.getWorkedDate().isAfter(currentDate)) {
            System.out.println("La fecha de trabajo no puede ser posterior a la fecha actual.");
            throw new IllegalArgumentException("La fecha de trabajo no puede ser posterior a la fecha actual.");
        }

        // Validar que no se duplique el registro por empleado y día
        if (employeeWorkedHoursRepository.existsByEmployeeIdAndWorkedDate(employeeWorkedHours.getEmployee().getId(), employeeWorkedHours.getWorkedDate())) {
            System.out.println("El empleado ya tiene un registro de horas trabajadas para esta fecha.");
            throw new IllegalArgumentException("El empleado ya tiene un registro de horas trabajadas para esta fecha.");
        }

        // Guardar las horas trabajadas del empleado
        EmployeeWorkedHours workedHours = new EmployeeWorkedHours();
        workedHours.setEmployee(employeeWorkedHours.getEmployee());
        workedHours.setWorkedHours(employeeWorkedHours.getWorkedHours());
        workedHours.setWorkedDate(employeeWorkedHours.getWorkedDate());

        EmployeeWorkedHours savedEmployeeWorkedHours = employeeWorkedHoursRepository.save(employeeWorkedHours);
        return savedEmployeeWorkedHours.getId();
    }
}